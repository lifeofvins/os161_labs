proc.o: ../../proc/proc.c ../../include/types.h \
 ../../include/kern/types.h includelinks/kern/machine/types.h \
 includelinks/machine/types.h ../../include/spl.h ../../include/cdefs.h \
 ../../include/proc.h ../../include/spinlock.h ../../include/hangman.h \
 opt-hangman.h includelinks/machine/spinlock.h ../../include/limits.h \
 ../../include/kern/limits.h ../../include/current.h \
 includelinks/machine/current.h ../../include/thread.h \
 ../../include/array.h ../../include/lib.h opt-noasserts.h \
 ../../include/threadlist.h includelinks/machine/thread.h \
 ../../include/setjmp.h includelinks/kern/machine/setjmp.h opt-waitpid.h \
 opt-file.h opt-fork.h ../../include/addrspace.h ../../include/vm.h \
 includelinks/machine/vm.h opt-dumbvm.h ../../include/vnode.h \
 ../../include/syscall.h opt-syscalls.h ../../include/synch.h opt-synch.h
