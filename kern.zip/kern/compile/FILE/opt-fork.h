/* Automatically generated; do not edit */
#ifndef _OPT_FORK_H_
#define _OPT_FORK_H_
#define OPT_FORK 1
#endif /* _OPT_FORK_H_ */
