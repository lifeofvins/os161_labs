/* Automatically generated; do not edit */
#ifndef _OPT_LAB1_H_
#define _OPT_LAB1_H_
#define OPT_LAB1 0
#endif /* _OPT_LAB1_H_ */
