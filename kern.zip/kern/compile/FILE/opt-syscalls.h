/* Automatically generated; do not edit */
#ifndef _OPT_SYSCALLS_H_
#define _OPT_SYSCALLS_H_
#define OPT_SYSCALLS 1
#endif /* _OPT_SYSCALLS_H_ */
